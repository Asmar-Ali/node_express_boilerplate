const server = require('./index');


const server = server