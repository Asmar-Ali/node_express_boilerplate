module.exports.ReportModel = require('./report.model')
module.exports.VehicleModel = require('./IMS/vehicle.model')
module.exports.TireModel = require('./IMS/tire.model')
module.exports.DepartmentModel = require('./UMS/department.model')
module.exports.UserModel = require('./UMS/user.model')
module.exports.DriverModel = require('./UMS/driver.model')
module.exports.GroupModel = require('./UMS/group.model')
module.exports.PermissionModel = require('./UMS/permission.model')


